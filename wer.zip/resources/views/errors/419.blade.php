<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page Expired</title>
</head>
<body style="color:green;">
    <h1>
        Page Expired!
    </h1>
    <h3>You have Stayed too long since you login without doing anything!. Please Try Logining in again!. click 
        <a href="/login">here</a>
    </h3>
    
</body>
</html>